#include<iostream>
using namespace std;

int main()
{
    int n=0, d=2, f=1, r=0;

    cout<<"Ingrese Numero: ";cin>>n;
    for (int i=1; i<=n;i++){
        r=i;
        while (d<=i){
            if (i%d==0){
                f=f*d;
                i=i/d;
                d=2;
            }
            else{
                d++;
            }
        }
        i=r;
    }
    if (n>3){
        f=f/2;
    }
    cout<<"El minimo comun multiplo es: "<<f;

    return 0;
}
