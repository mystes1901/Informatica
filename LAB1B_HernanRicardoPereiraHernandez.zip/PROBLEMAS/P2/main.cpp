#include <iostream>
using namespace std;

int main()
{
    int cincuenta=0,veinte=0,diez=0,cinco=0,dos=0,mil=0,
        quinientos=0,doscientos=0,cien=0,v=0,billete=0;

        cout<<"Valor de la devueta: ";cin>>billete;

        while(billete>=50000){
            billete=billete-50000;
            cincuenta++;
        }
        cout<<"50mil: "<<cincuenta<<endl;
        while(billete>=20000){
            billete=billete-20000;
            veinte++;
        }
        cout<<"20mil: "<<veinte<<endl;
        while(billete>=10000){
            billete=billete-10000;
            diez++;
        }
        cout<<"10mil: "<<diez<<endl;
        while(billete>=5000){
            billete=billete-5000;
            cinco++;
        }
        cout<<"5mil: "<<cinco<<endl;
        while(billete>=2000){
            billete=billete-2000;
            dos++;
        }
        cout<<"2mil: "<<dos<<endl;
        while(billete>=1000){
            billete=billete-1000;
            mil++;
        }
        cout<<"mil: "<<mil<<endl;
        while(billete>=500){
            billete=billete-500;
            quinientos++;
        }
        cout<<"500: "<<quinientos<<endl;
        while(billete>=200){
            billete=billete-200;
            doscientos++;
        }
        cout<<"200: "<<doscientos<<endl;
        while(billete>=100){
            billete=billete-100;
            cien++;
        }
        cout<<"100: "<<cien<<endl;
        while(billete>=50){
            billete=billete-50;
            v++;
        }
        cout<<"50: "<<v<<endl;
        cout<<"Faltante: "<<billete<<endl;
    return 0;
}

