#include <iostream>

using namespace std;

int main(){
    int entero=0, digito=0, exponente=0, suma=0, p=0; //variables
    cout<<"ingrese numero: ";cin>>entero;
    while(entero>0){
        digito=entero%10;//obtener el ultimo digito
        exponente=digito;
        p=digito;//reiniciar la variable p
        while(digito>1){
            p=p*exponente;//realizar multiplicacion
            --digito;//reduir las veces en las que se multiplica
        }
        digito=p;//tomar el valor de n^n para luego sumar
        suma=suma+digito;
        entero=entero/10;//eliminar ultimo digito
    }
    cout<<"Suma: "<<suma<<endl;
    return 0;
}
