#include<iostream>

using namespace std;

int main()
{

    int n=0, f=0, b=1, suma=0;

    cout<<"Ingrese Numero: ";cin>>n;

    while (f<n){
        b=b+f;
        f=b-f;
        if (f<n){
            if(f%2==0){
                cout<<f<<endl;
                suma=suma+f;
            }
        }
    }
    cout<<"suma: "<<suma<<endl;
return 0;
}
