#include <iostream>

using namespace std;

int main()
{
    int contador, n, primo ,m=0,suma=0;

    cout<<"Ingrese numero: ";cin>>m;

    for ( n = 1 ; n <= m; n++ )
    {
        primo = 1;
        contador = 2;

        while ( contador <= n / 2 && primo )
        {
            if ( n % contador == 0 )
                primo = 0;

            contador++;
        }

        if ( primo ){
            cout<<n<<"  ";
            suma=suma+n;
            }
    }
    cout<<"\nSuma de los N Primos: "<<suma-1;

    return 0;
}
