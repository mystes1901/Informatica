#include <iostream>

using namespace std;
//Problema 14
int main()
{
    int n=0,m=0,l=0,u=0,pal=0,k1=0,k2=0,w=0,menor=0,mayor=0;
    cout<<"MULTIPLICAR NUMEROS ENTRE... "<<endl;
    cout<<"Ingrese numero Menor= ";cin>>menor;
    cout<<"...Y...\n";
    cout<<"Ingrese numero Mayor= ";cin>>mayor;
    for (int i=menor;i<=mayor;i++ ) {//Primer entero
        for(int j=i+1;j<=mayor;j++){//segundo
            m=i*j;//Entero principal
            n=m;
            l=0;//Para que se reinicie la variable
            while(n>0){//Ciclo para invertir el numero
                u=n%10;
                l=l+u;
                l=l*10;
                n=n/10;
            }
            l=l/10;//Numero invertido
            if(m==l){//Comparacin del entero principal con el numero invertido
                if(m!=w){
                    cout<<i<<" * "<<j<<" = "<<m<<endl;
                    w=m;
                    }
                if(m>pal){//Para seleccionar el palindromo mayor
                    k1=i;//primer entero
                    k2=j;//segundo entero
                    pal=m;//Palindromo
                }

            }
        }
    }
    cout<<"\nPalindromo Mayor: "<<k1<<" * "<<k2<<" = "<<pal<<endl;
    return 0;
}
