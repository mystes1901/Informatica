#include<iostream>
using namespace std;

int main()
{
    int a=0,b=0,c=0,am=0,bm=0,suma=0,i=1,ams=0,bms=0;

    cout<<"Ingrese Numero A: ";cin>>a;
    cout<<"Ingrese Numero B: ";cin>>b;
    cout<<"Ingrese Numero C: ";cin>>c;

    while (i<c){
        am=a*i;
        bm=b*i;
        if (am==bm){
            bm=0;
        }
        if (am<=c){
            ams=ams+am;
        }
        if (bm<=c){
            bms=bms+bm;
        }
        i++;
    }
    suma=ams+bms;
    cout<<"Suma: "<<suma;
    return 0;
}
