#include <iostream>
using namespace std;

int main()
{
    char letra;
    cout<<"Digite la letra:\n";cin>>letra;

    if(letra=='a' || letra=='e' || letra=='i' || letra=='o' || letra=='u'||
    letra=='A' || letra=='E' || letra=='I' || letra=='O' || letra=='U')
    {
        cout<<letra<<" es una vocal"<<endl;
    }
    else
    {
        if(letra=='q' ||letra=='w' ||letra=='r' ||letra=='t' ||letra=='y' ||letra=='p' ||letra=='ñ'||
        letra=='l' ||letra=='k' ||letra=='j' ||letra=='h' ||
        letra=='g' ||letra=='f' ||letra=='d' ||letra=='s' ||letra=='z' ||letra=='x' ||letra=='c' ||
        letra=='v' ||letra=='b' ||letra=='n' ||letra=='m'||letra=='Q' ||letra=='W' ||letra=='R' ||
        letra=='T' ||letra=='Y' ||letra=='P' ||letra=='Ñ' ||letra=='L' ||letra=='K' ||letra=='J' ||letra=='H' ||
        letra=='G' ||letra=='F' ||letra=='D' ||letra=='S' ||letra=='Z' ||letra=='X' ||letra=='C' ||
        letra=='V' ||letra=='B' ||letra=='N' ||letra=='M')
        {
            cout<<letra<<" es consonante"<<endl;
        }
        else
        {
            cout<<letra<<" No es ni vocal ni consonante"<<endl;
        }
    }

    return 0;
}

