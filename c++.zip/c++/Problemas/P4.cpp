#include <iostream>

using namespace std;

int main()
{   
    int xhora=0,ytiempo=0,hora=0,minuto=0,h=0,hora1=0,minuto1=0,h1=0;
    std::cout << "numero: " << std::endl;std::cin >> xhora;//primer entero (hora)
    cout<<"Tiempo de duracion: "<<endl;std::cin >> ytiempo;//segundo entero(Tiempo)
    if (xhora<=2399){
        if((ytiempo/100+xhora/100)<=23){
            ///////////////SEGUNDO ENTERO
            minuto1=ytiempo%100;//del entero se estraen los dos ultimos digitos.
            if (minuto1>=60){
                h1=minuto1/60;//suma una hora
                minuto1=minuto%60;
            }
            hora1=ytiempo/100;//obtengo los numeros sobrantes de retirar los ultimos digitos.
            hora1=hora1+h1;
            /////////////HORA(PRIMER ENTERO)
            minuto=xhora%100+minuto1;//del entero se estraen los dos ultimos digitos.
            if (minuto>=60){
                h=minuto/60;//suma una hora
                minuto=minuto%60;
            }
            hora=xhora/100;//obtengo los numeros sobrantes de retirar los ultimos digitos.
            hora=hora+h+hora1;
            if (hora>23){
                cout<<"0";
                hora=0;
            }
            if (minuto<10){
                hora=hora*10;
            }
            cout<<hora<<minuto<<endl;    
        }
        else{
            cout<<"Formato invalido"<<endl;
        }
        
    }
    else{
        if(xhora==2400){
            cout<<"Hora 0000"<<endl;
           
        }
        else{
            cout<<"Formato de hora invalido"<<endl;
        }
    }
    return 0;
}
