#include<iostream>
using namespace std;

int main()
{
	int mes=0, dia=0;
	
	cout<<"Mes: ";cin>>mes;
	if (mes>=1 && mes<=12){
		cout<<"Dia: ";cin>>dia;
		if (mes==1 || mes==3 ||mes==5 || mes==7 ||mes==8 || mes==10 ||mes==12){
			if (dia>=1 && dia<=31){
				cout<<dia<<"/"<<mes<<" Es una fecha valida.";
			}
			else {
				cout<<dia<<"/"<<mes<<" No es una fecha valida.";
			}
		}
		if (mes==4 || mes==6 ||mes==9 || mes==11){
			if (dia>=1 && dia<=30){
				cout<<dia<<"/"<<mes<<" Es una fecha valida.";
			}
			else {
				cout<<dia<<"/"<<mes<<" No es una fecha valida.";
			}
		}
		if (mes==2){
			if (dia>=1 && dia<=29){
				if (dia==29){
					cout<<"Posible año bisiesto\n";
				}
				cout<<dia<<"/"<<mes<<" Es una fecha valida.";
			}
			else {
				cout<<dia<<"/"<<mes<<" No es una fecha valida.";
			}
		}
	}
	else{
		cout<<" Mes No valido";
	}
	
	return 0;	
}