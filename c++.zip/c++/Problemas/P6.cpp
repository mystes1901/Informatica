#include<iostream>
using namespace std;

int main()
{
	float num=0, h=0,c=0;
	float f=0,e=0;
	cout<<"Ingrese numero: "<<endl;cin>>num;
	if (num==0){num++;}
	num=num-1;
	while(num>=0){
		c=1;h=1;
		for(int i=1; i<=num; i++){
			h=h*c;
			c++;
			}
		f=1/h;
		e=e+f;
		num--;	
		}
	cout<<"e: "<<e<<endl;
	
return 0;
}