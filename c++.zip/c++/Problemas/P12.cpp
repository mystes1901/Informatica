#include <iostream>

using namespace std;

int main()
{
	int numero=0, x=2, p=0;
	cout<<"Numero: ";cin>>numero;
	p=numero;
	
	while (numero != 1){
		if (numero % x == 0){
			numero=numero/x;
		}
		else{
			x=x+1;
		}
	}
	cout<<"El mayor factor Primo de  "<<p<<"  es: "<<x<<endl;
	
	return 0;
}