#include <iostream>
using namespace std;

int main()
{
    int n, c=1, p=0;

    cout<<"DIgite numero: ";cin>>n;//enter number

    while(c<=10)
    {
        p=c*n;//multiplication product
        cout<<c<<"x"<<n<<"="<<p<<endl; //show result
        c=c+1;//add one to the counter
    }

    return 0;
}
