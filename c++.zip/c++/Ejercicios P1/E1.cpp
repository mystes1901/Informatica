#include <iostream>

using namespace std;

int main()
//Remainder of a division:
{
    int a, b, c;    //variable to use
    cout<<"Digite primer numero: ";cin>>a;
    cout<<"Digite segundo numero: ";cin>>b;

    c=a%b; //calculate remainder

    cout<<"Residuo: "<< c; //show remainder

    return 0;

}
