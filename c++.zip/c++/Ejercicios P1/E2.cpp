#include<iostream>

using namespace std;

int main()
//Even number and odd number:
{
    int a, b;

    cout<<"Digite un numero:";cin>>a;
    b=a%2;//calculate remainder

    if(b==0) //Is even number if b is equal to 0
        cout<<a<<" Es un numero PAR.\n ";
    else
        cout<<a<<" Es un numero IMPAR.\n";

    return 0;

}
