#include <iostream>
using namespace std;
//CAlculate smaller number
int main()
{
    float a,b;
    //enter numbers:
    cout<<"Digite primer numero: "<<endl;cin>>a;
    cout<<"Digite Segundo numero numero: "<<endl;cin>>b;
    if (a<=b)//Comparate numbers
    {
        if (a==b) //the numbers are same
        {
            cout<<"Los numeros son iguales"<<endl;
        }
        else //The smaller number is A
        {
            cout<<a<<" Es el numero menor"<<endl;
        }
    }
    else //the smaller number is B
    {
        cout<<b<<" Es el numero menor"<<endl;
    }

    return 0;
}
