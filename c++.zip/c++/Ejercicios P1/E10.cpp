#include <iostream>
using namespace std;

int main()
{
    int n, c=1, m;//variables to use

    cout<<"Ingrese Numero: "<<endl;cin>>n;
    cout<<"Multiplos de "<<n<<" menores que 100:"<<endl;

    while (c<=100)//C= counter
    {
        m=c%n; //know the rest of the division

        if (m==0)//if the module is O, then it's multiple
        {
            cout<<c<<endl;
        }
        c=c+1; //add one to the counter
    }
    return 0;
}

