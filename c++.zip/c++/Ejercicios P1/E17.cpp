#include <iostream>
using namespace std;
//larger number
int main()
{
    int n=0,m=0; //variables to use

    cout<<"Enter number: ";cin>>n;
    m=n; // M= larger number
    while(n!=0)
    {
        cout<<"Enter number: ";cin>>n;
        if(n>m) //compare numbers
        {
            m=n; //larger number
        }
    }
    cout<<"El numero mayor fue: "<<m<<endl;//show number M
    return 0;
}

