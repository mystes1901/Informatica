#include <iostream>
using namespace std;

int main()
{
    int n, suma; //variables to use

    cout<<"Digite numero: "<<endl;cin>>n; //Enter number

    suma=(n*(n+1))/2; //Gauss's law

    cout<<"La sumatoria desde 0 hasta "<<n<<" es: "<<suma<<endl; //Show sum

    return 0;
}
