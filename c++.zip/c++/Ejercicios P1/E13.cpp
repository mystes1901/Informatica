#include <iostream>
using namespace std;
//Divisor
int main()
{
    int n, r, c=1;

    cout<<"Enter number: ";cin>>n;
    cout<<"Los divisores de "<<n<<" son:"<<endl;
    while(c<=n) //c is a counter
    {
        r=n%c; //calculate residue
        if(r==0)//r is a divisor
        {
            cout<<c<<endl;
        }
        c=c+1; //add one to the counter

    }

    return 0;
}

