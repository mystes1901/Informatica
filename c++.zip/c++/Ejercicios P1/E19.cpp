#include <iostream>
using namespace std;
//Prime number
int main()
{
    int n, d=1, r=0, c=0;//n=number, d=divider r= remainder c=divider counter
    cout<<"Enter number: ";cin>>n;

    if(n<=1)//the ṕrime numbers only are natural numbers
     {
        cout<<n<<" NO es un numero primo"<<endl;
    }
    else
    {
        while(d<=n)
        {
            r=n%d;
            if(r==0)//d is divider
            {
                c=c+1;
            }
            d=d+1;
        }
        if(c==2)//if the divider counter is equal to 2, then is prime
        {
            cout<<n<<" es un numero primo"<<endl;
        }
        else
        {
            cout<<n<<" NO es un numero primo"<<endl;
        }
    }

    return 0;
}
