#include <iostream>
using namespace std;

int main()
{
    float a,b,c,d,e,f,g;//Variables a usar

    cout<<"Digine numero base: ";cin>>a;
    cout<<"Digine numero exponente: ";cin>>b;

    if(b>=0)//Si el exponente es positivo o negativo
    {
        if (b==0)//si el exponente es cero R=1
        {

            cout<<a<<"^"<<b<<"= 1"<<endl;
        }
        else//Exponente positivo
        {
            c=b-1;//Contador
            d=a;//Acumulador
            while(c>0)
            {
                d=d*a;
                c=c-1;
            }
            cout<<a<<"^"<<b<<"= "<<d<<endl;
        }
    }
    else//exponente negativo
    {
        e=b*(-1);//Exponente de negativo a positivo
        e=e-1;
        f=a;
            while(e>0)//a^n
            {
                f=f*a;
                e=e-1;
            }
        g=1/f; //a^-n=1/a^n
        cout<<a<<"^"<<b<<"= "<<g<<endl;
    }
    return 0;
}
