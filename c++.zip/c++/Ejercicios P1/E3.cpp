#include <iostream>
using namespace std;
//know major number:
int main()
{
    float a,b;
    cout<<"Digite primer numero: "<<endl;cin>>a;
    cout<<"Digite Segundo numero numero: "<<endl;cin>>b;
    if (a>=b)//Compare numbers
    {
        if (a==b) // if the numbers are the same
        {
            cout<<"Los numeros son iguales"<<endl;
        }
        else //the first number is the major
        {
            cout<<a<<" Es el numero mayor"<<endl;
        }
    }
    else //the second number is the major
    {
        cout<<b<<" Es el numero mayor"<<endl;
    }

    return 0;
}
