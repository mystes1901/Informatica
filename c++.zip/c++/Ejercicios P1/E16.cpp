#include <iostream>
using namespace std;

int main()
{
    int n=0, s=0, c=0, p;//variables to use

    cout<<"Enter number: ";cin>>n;//enter number
    s=n;//add equal to the number
    while(n!=0)//compare number with zero
    {
        cout<<"Enter number: ";cin>>n;//enter other number
        s=s+n;//add
        c=c+1;//counter
    }
    p=s/c;//average

    cout<<"El promedio es: "<<p<<endl;//show averege

    return 0;
}

