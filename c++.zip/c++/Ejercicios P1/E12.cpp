#include <iostream>
using namespace std;

int main()
{
    int n, p=1, r=0; //define variables to use

    cout<<"Ingrese numero: ";cin>>n;
    r=n; //Result equal to the number entered
    while(p<=5) //the exponent give the condition
    {
        cout<<n<<"^"<<p<<"="<<r<<endl;//first it shows when R is equal to N
        r=r*n; //multiplies
        p=p+1; //add one to the exponent
    }
    return 0;
}

