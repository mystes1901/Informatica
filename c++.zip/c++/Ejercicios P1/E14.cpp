#include <iostream>
using namespace std;
//two columns
int main()
{
    int n1=1, n2=0, c=0;
    cout<<"Ingrese numero: ";cin>>n2;
    c=n2; //conditional equal to the second number
    while(n1<=c)
    {
        cout<<n1<<"  |  "<<n2<<endl;//show two columns

        n1=n1+1; //add one to the second number
        n2=n2-1; //rest one to the second number
    }
    return 0;
}

