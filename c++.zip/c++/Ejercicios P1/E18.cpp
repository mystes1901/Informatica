#include <iostream>
using namespace std;

int main()
{
    int n=0, c=0, c2; //c is the counter

    cout<<"Enter number: ";cin>>n;
    //perfect square
    while(c<=n)
    {
        c2=c*c; //c^2
        if(c2==n)// if n=c^2 then n is perfect square
        {
            cout<<n<<" es un cuadrado perfecto."<<endl;
            c=n+1; //end cylcle
        }
        if(c2>n)// if c^2 is greater than,then n is not perfect square
        {
            cout<<n<<" NO es un cuadrado perfecto."<<endl;
            c=n+1; //end cycle
        }
        c=c+1;//add one to the counter
    }
    return 0;
}
