#include <iostream>
using namespace std;
// add of numbers entered different from zero
int main()
{
    int n=0, s=0;//variables

    cout<<"Enter number:";cin>>n;//enter number
    s=n; //add equal to the numeber
    while(n!=0) //compare number with zero
    {
        cout<<"Enter number:";cin>>n;//enter other number
        s=n+s; //add number to the S
    }
    cout<<"El resultado de la sumatoria es: "<<s<<endl;//show add
    return 0;
}
