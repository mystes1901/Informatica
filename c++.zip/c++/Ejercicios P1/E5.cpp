#include<iostream>

using namespace std;

int main()

{
    float a=0,b=0,c=0,e=0,f=0.5; //Variables a usar
    int d=0,s=0;

    cout<<"Primer numero: ";cin>>a;
    cout<<"Segundo numero: ";cin>>b;
    c=a/b; //Solucion float
    d=a/b; //Solucion int
    e=c-d; //Obtener solo decimales

    if (e<=f)//Decimales mayor o menor que 0.5
    {
        if(e==f) //comparar decimales con 0.5
        {
            s=d+1;//Redondeo superior
            if (s%2==0)//Comprobar si es par
            {
                cout<<a<<" / "<<b<<" = "<<s;
            }
            else//Solo imprime el int
            {
                cout<<a<<" / "<<b<<" = "<<d;
            }
        }
        else //Se redondea a la solucion int
        {
            cout<<a<<" / "<<b<<" = "<<d;
        }
    }
    else //Se resondea al numero entero sigiente
    {
        d=d+1;
        cout<<a<<" / "<<b<<" = "<<d;
    }
    return 0;
}
