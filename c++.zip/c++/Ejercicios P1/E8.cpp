#include<iostream>
using namespace std;

int main()

{
    int p, n, a, f=0;
    cout<<"Digite Numero: ";
    cin>>p;
    n=p;
    a=n-1;

    while(a>0)
    {
        f=n*a;
        n=f;
        a=a-1;
    }
    cout<<endl<<p<<"! : "<<f<<endl;

return 0;
}
