#include <iostream>
#include <string.h>
#include <stdlib.h>

using namespace std;

int main()
{
    char num[10] ,num2[10], num3[10], i;
    int lon=0;
    cout<<"Ingrese numero: ";cin.getline(num,10,'\n');
    cout<<num<<endl;
    strcpy(num2,num);

    lon=strlen(num2);
    strcat(num3,num);
    cout<<num3<<endl;
    while(lon>=0)
    {
        i=num2[lon-1];
        cout<<i<<endl;



        lon=lon-1;

    }
    return 0;
}
